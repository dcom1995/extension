//
//  ActionViewController.swift
//  actionExtension
//
//  Created by yash on 8/24/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit
import MobileCoreServices
import  AVFoundation

class ActionViewController: UIViewController {

    @IBOutlet var textViewDisplay: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let item: NSExtensionItem? = extensionContext?.inputItems[0] as? NSExtensionItem
        let itemProvider: NSItemProvider? = item?.attachments?[0] as? NSItemProvider
        if (itemProvider?.hasItemConformingToTypeIdentifier((kUTTypePlainText as? String)!))! {
            // It's a plain text!
            weak var textView: UITextView? = textViewDisplay
            
            itemProvider?.loadItem(forTypeIdentifier: (kUTTypePlainText as? String)!, options: nil, completionHandler: {(string,error) -> Void in
                if item != nil {
                    OperationQueue.main.addOperation({() -> Void in
                        textView?.text = string as? String ?? ""
                        // Set up speech synthesizer and start it
                        let synthesizer = AVSpeechSynthesizer()
                        let utterance = AVSpeechUtterance(string: (self.textViewDisplay?.text)!)
                        utterance.rate = 0.1
                        synthesizer.speak(utterance)
                    })
                }
            })
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func done() {
        // Return any edited content to the host app.
        // This template doesn't do anything, so we just echo the passed in items.
        self.extensionContext!.completeRequest(returningItems: self.extensionContext!.inputItems, completionHandler: nil)
    }

}
