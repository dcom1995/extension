//
//  ShareViewController.swift
//  TodayShare
//
//  Created by yash on 8/24/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit
import Social
import MobileCoreServices

class ShareViewController: SLComposeServiceViewController {
    let suiteName = "group.com.zaptechsolutions.Extension"
    var selectedImage: UIImage?
    override func isContentValid() -> Bool {
        // Do validation of contentText and/or NSExtensionContext attachments here
        //        didSelectPost()
        return true
    }
    override func didSelectPost() {
        
        // This is called after the user selects Post.
        // Make sure we have a valid extension item
        if let content = extensionContext!.inputItems[0] as? NSExtensionItem {
            let contentType = kUTTypeImage as String
            
            // Verify the provider is valid
            if let contents = content.attachments as? [NSItemProvider] {
                
                // look for images
                for attachment in contents {
                    if attachment.hasItemConformingToTypeIdentifier(contentType) {
                        attachment.loadItem(forTypeIdentifier: contentType, options: nil) { data, error in
                            
                            let url = data as! URL
                            
                            if let imgData = try? Data(contentsOf: url) {
                                
                                let dict: [AnyHashable: Any] = ["imgData":imgData,"name":self.contentText]
                                let defaults = UserDefaults(suiteName: "group.com.zaptechsolutions.Extension")
                                defaults?.set(dict, forKey: "img")
                                defaults?.synchronize()
                            }
                        }
                    }
                }
            }
        }
           // Inform the host that we're done, so it un-blocks its UI.
        self.extensionContext!.completeRequest(returningItems: [], completionHandler: nil)
    }
    
    
    override func configurationItems() -> [Any]! {
        // To add configuration options via table cells at the bottom of the sheet, return an array of SLComposeSheetConfigurationItem here.
        return []
    }
    
}
