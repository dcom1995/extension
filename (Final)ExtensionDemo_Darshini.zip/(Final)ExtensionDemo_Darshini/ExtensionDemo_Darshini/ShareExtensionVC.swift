//
//  ShareExtensionVC.swift
//  ExtensionDemo_Darshini
//
//  Created by yash on 8/25/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit

class ShareExtensionVC: UIViewController {

    @IBOutlet var lblName: UILabel!
    
    
    @IBOutlet var ImgView: UIImageView!
    let suiteName = "group.com.zaptechsolutions.Extension"
    override func viewDidLoad() {
        super.viewDidLoad()
        if let defaults = UserDefaults(suiteName: suiteName) {
            var dict = defaults.value(forKey: "img") as? [AnyHashable: Any] ?? [AnyHashable: Any]()
            if !dict.isEmpty {
                
                let imgData = dict["imgData"] as? Data ?? Data()
                ImgView.image = UIImage(data: imgData)
                print("data =\(imgData)")
                lblName.text = dict["name"] as? String
                defaults.removeObject(forKey: "img")
            }
            
        }
  
    }
        override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
