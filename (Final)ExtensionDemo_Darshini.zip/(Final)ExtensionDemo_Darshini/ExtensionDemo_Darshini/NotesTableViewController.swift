
import UIKit

class NotesTableViewController: UITableViewController {
  
  // MARK: - Properties
  var notes = [Note]()
    var titleNotes = NSArray()
  let noteSegueIdentifier = "noteSegue"
  fileprivate lazy var dateFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    return formatter
  }()
  
    @IBAction func addButtonTapped(_ sender: Any) {
        
            let alertController = UIAlertController(title: "Add Note", message: "Please enter a title for your new note", preferredStyle: .alert)
            alertController.addTextField { textField in
              textField.placeholder = "Note Title"
            }
        
            alertController.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
        
            let okayAction = UIAlertAction(title: "Okay", style: .default) { action in
              guard let noteTitle = alertController.textFields?.first?.text else {
                return
              }
        
              guard let note = Note.createNote(noteTitle) else {
                return
              }
        
              note.save(to: note.fileURL, for: .forCreating) { [unowned self] (success) -> Void in
                guard success else {
                  print("Save unsuccessful")
                  return
                }
        
                self.performSegue(withIdentifier: self.noteSegueIdentifier, sender: note)
                self.notes.append(note)
              }
            }
            
            alertController.addAction(okayAction)
            present(alertController, animated: true, completion: nil)
          }
  // MARK: - View Life Cycle
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    
    refreshNoteList()
  }
  
  // MARK: - Navigation
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    guard segue.identifier == noteSegueIdentifier else {
      return
    }
    
    let noteViewController = segue.destination as! NoteViewController
    let noteDocument = sender as! Note
    noteViewController.note = noteDocument
  }
}

// MARK: - Internal
extension NotesTableViewController {
  
  func refreshNoteList() {
    notes = Note.getAllNotesInFileSystem()
    tableView.reloadData()
  }
    
    
}

// MARK: - IBActions
extension NotesTableViewController {
 }

// MARK: - UITableViewDataSource
extension NotesTableViewController {
  
  // MARK: - CellIdentifiers
  fileprivate enum CellIdentifier: String {
    case NoteCell = "noteCell"
  }
  
  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return notes.count
  }
  
  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier.NoteCell.rawValue, for: indexPath)
    let noteDocument = notes[(indexPath as NSIndexPath).row]
    cell.textLabel?.text = noteDocument.title
    titleNotes = [noteDocument.title]
    return cell
  }
}

// MARK: - UITableViewDelegate
extension NotesTableViewController {
  
  override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    tableView.deselectRow(at: indexPath, animated: true)
    

    let activityVC = UIActivityViewController(activityItems: titleNotes as! [Any], applicationActivities: nil)
    activityVC.popoverPresentationController?
        .sourceView = self.view // so that iPads won't crash
    present(activityVC, animated: true) { _ in }
    
//    let noteDocument = notes[(indexPath as NSIndexPath).row]
//    performSegue(withIdentifier: noteSegueIdentifier, sender: noteDocument)
  }
}
