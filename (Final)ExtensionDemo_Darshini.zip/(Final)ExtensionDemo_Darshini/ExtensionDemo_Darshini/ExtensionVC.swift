//
//  ExtensionVC.swift
//  ExtensionDemo_Darshini
//
//  Created by yash on 8/24/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit


class ExtensionVC: UIViewController,UITextViewDelegate,UITextFieldDelegate {

    @IBOutlet var txtViewToday: UITextField!
    @IBOutlet var textView: UITextView!
        @IBOutlet var ImgView: UIImageView!
    
    @IBOutlet var lblName: UILabel!
    
    @IBOutlet var txtViewDoc: UITextView!
    
    @IBAction func onBtnDocSubmit(_ sender: Any) {
//        let objShareVC = self.storyboard?.instantiateViewController(withIdentifier: "NotesTableViewController") as! NotesTableViewController
//        self.navigationController?.pushViewController(objShareVC, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        textView.delegate = self
        txtViewToday.delegate = self
//        let defaults = UserDefaults(suiteName: "group.com.zaptechsolutions.Extension")
//        var dict = defaults?.value(forKey: "img") as? [AnyHashable: Any] ?? [AnyHashable: Any]()
//        if !dict.isEmpty {
//            
//            let imgData = dict["imgData"] as? Data ?? Data()
//            ImgView.image = UIImage(data: imgData)
//            print("data =\(imgData)")
//            lblName.text = dict["name"] as? String
//            defaults?.removeObject(forKey: "img")
//        }
        
    }

    
    
     func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool
    {
        if(text == "\n")
        {
            view.endEditing(true)
            return false
        }
        else
        {
            return true
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool  {
        if(string == "\n")
        {
            view.endEditing(true)
            return false
        }
        else
        {
            return true
        }
    }
    
       @IBAction func onBtnTodayExtension(_ sender: Any) {
        let sharedDefaults = UserDefaults(suiteName: "group.com.zaptechsolutions.Extension")
        sharedDefaults?.set(CInt(txtViewToday.text!), forKey: "MyNumberKey")
        sharedDefaults?.synchronize()
    }

 
    @IBAction func onBtnShareExtension(_ sender: Any) {
        let objShareVC = self.storyboard?.instantiateViewController(withIdentifier: "ShareExtensionVC") as! ShareExtensionVC
        self.navigationController?.pushViewController(objShareVC, animated: true)
    }
    @IBAction func onBtnActionExt(_ sender: Any) {
        let activityVC = UIActivityViewController(activityItems: [textView.text], applicationActivities: nil)
        activityVC.popoverPresentationController?
            .sourceView = self.view // so that iPads won't crash
        present(activityVC, animated: true) { _ in }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
