
import UIKit

class NoteViewController: UIViewController {

  // MARK: - Properties
  var note: Note!

  // MARK: - IBOutlets
  

    @IBOutlet var textView: UITextView!
  // MARK: - View Life Cycle
  override func viewDidLoad() {
    super.viewDidLoad()

    note.open { [unowned self] success in
      guard success else {
        self.displayAlert(title: NSLocalizedString("Error", comment: ""),
          message: NSLocalizedString("Error opening note", comment: ""))
        return
      }

      self.title = self.note.title
      self.textView.text = self.note.documentText
    }
  }
  
    @IBAction func saveButtonTapped(_ sender: Any) {
                    note.documentText = textView.text
                    note.save(to: note.fileURL, for: .
                    forOverwriting) { [unowned self] success in
                      var title = "Note Saved"
                      var message = "Note Saved Successfully"
        
                      if !success {
                        title = "Note Not Saved"
                        message = "Error Saving Note"
                      }
        
                      self.displayAlert(title: title, message: message)
                    }
            
                
        
            }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)

    textView.becomeFirstResponder()
  }
}

// MARK: - IBActions
extension NoteViewController {

//  @IBAction func saveButtonTapped(sender: AnyObject) {
//    note.documentText = textView.text
//    note.save(to: note.fileURL, for: .forOverwriting) { [unowned self] success in
//      var title = "Note Saved"
//      var message = "Note Saved Successfully"
//
//      if !success {
//        title = "Note Not Saved"
//        message = "Error Saving Note"
//      }
//
//      self.displayAlert(title: title, message: message)
//    }
//  }
}

// MARK: - Private
private extension NoteViewController {

  /**
   Helper method to display a fully configured **UIAlertController** to the user

   - parameter title: **UIAlertController's** title text
   - parameter message: **UIAlertController's** message text
   */
  func displayAlert(title: String, message: String) {
    let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
    alertController.addAction(UIAlertAction(title: NSLocalizedString("Dismiss", comment: ""), style: .default, handler: nil))
    present(alertController, animated: true, completion: nil)
  }
}
