

import UIKit

enum DocumentError : Error {
  case runtimeError(String)
}

class Note: UIDocument {
  
  // MARK: - Static-Properties
  static let fileExtension = "txt"
  static let appGroupIdentifier = "group.com.zaptechsolutions.Extension"
  
  // MARK: - Properties
  var documentText: String?
  var title: String!
  
  // MARK: - Overridden Instance Methods
  override func load(fromContents contents: Any, ofType typeName: String?) throws {
    guard let data = contents as? Data , data.count > 0 else { return }
    
    documentText = String(data: data, encoding: .utf8)
  }
  
  override func contents(forType typeName: String) throws -> Any {
    documentText = documentText ?? ""
    
    guard let documentData = documentText?.data(using: .utf8) else {
      throw DocumentError.runtimeError("Unable to convert String to data")
    }
    
    return documentData
  }
}

// MARK: - Static-Methods
extension Note {
  
  // Creates a note with a title/filename
  static func createNote(_ noteTitle: String) -> Note? {
    guard let fileURL = fileUrlForDocumentNamed(noteTitle) else { return nil }
    
    let noteDocument = Note(fileURL: fileURL)
    noteDocument.title = noteTitle
    
    return noteDocument
  }
  
  // Given an array of filenames, return an array of notes from the file system
  static func arrayOfNotesFromArrayOfFileNames(_ fileNames: [String]) -> [Note] {
    var notes: [Note] = []
    
    for fileName in fileNames {
      let noteTitle = fileName.replacingOccurrences(of: ".txt", with: "")
      
      guard let note = createNote(noteTitle) else { continue }
      notes.append(note)
    }
    return notes
  }
  
  // Returns all notes in file system
  static func getAllNotesInFileSystem() -> [Note] {
    guard let localDocumentsDirectory = appGroupContainerURL() else { return [] }
    
    let localDocumentsDirectoryPath = localDocumentsDirectory.path
    let localDocuments: [String]?
    do {
      localDocuments = try FileManager.default.contentsOfDirectory(atPath: localDocumentsDirectoryPath)
    } catch _ {
      print("error accessing contents from directory")
      localDocuments = nil
    }
    
    guard let fileNames = localDocuments else { return [] }
    
    return arrayOfNotesFromArrayOfFileNames(fileNames)
  }
  
  // Returns the file URL for the file to be saved at
  static func fileUrlForDocumentNamed(_ name: String) -> URL? {
    guard let baseURL = appGroupContainerURL() else { return nil }
    
    let protectedName: String
    if name.isEmpty {
      protectedName = "Untitled"
    } else {
      protectedName = name
    }
    
    return baseURL.appendingPathComponent(protectedName)
      .appendingPathExtension(fileExtension)
  }
  
  static func appGroupContainerURL() -> URL? {
    // 1
    let fileManager = FileManager.default
    guard let groupURL = fileManager
      .containerURL(forSecurityApplicationGroupIdentifier: appGroupIdentifier) else {
        return nil
    }
    
    let storagePathUrl = groupURL.appendingPathComponent("File Provider Storage")
    let storagePath = storagePathUrl.path
    // 2
    if !fileManager.fileExists(atPath: storagePath) {
      do {
        try fileManager.createDirectory(atPath: storagePath,
                                        withIntermediateDirectories: false,
                                        attributes: nil)
      } catch let error {
        print("error creating filepath: \(error)")
        return nil
      }
    }
    // 3
    return storagePathUrl
  }
  
  static func localDocumentsDirectoryURL() -> URL? {
    guard let documentPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first else { return nil }
    
    let localDocumentsDirectoryURL = URL(fileURLWithPath: documentPath)
    return localDocumentsDirectoryURL
  }
}


